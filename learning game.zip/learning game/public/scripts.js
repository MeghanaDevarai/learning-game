const questions = [
        { 
          question: '1.What is 5 + 3?', 
          answers: [7, 8, 9, 10], 
          correctAnswer: 8 
        },
        {
             question: '2.What is 7 * 6?',
            answers: [36, 42, 48, 54],
            correctAnswer: 42
        },
        { 
            question: '3.What is 9 - 4?', 
            answers: [4, 5, 6, 7], 
            correctAnswer: 5 
        },
        {
            question: '4.What is 20/4?', 
            answers: [4, 5, 2, 3], 
           correctAnswer: 5
        },
        {
            question: '5.What is 12 + 7?', 
            answers: [17, 18, 19, 20], 
            correctAnswer: 19 
        },
        { 
            question: '6.What is 15 * 4?', 
            answers: [55, 60, 65, 70], 
            correctAnswer: 60 
        },
        { 
            question: '7.What is 100 - 25?', 
            answers: [70, 75, 80, 85], 
            correctAnswer: 75 
        },
        { 
            question: '8.What is 81 / 9?', 
            answers: [7, 8, 9, 10], 
            correctAnswer: 9 
        },
        { 
            question: '9.What is the capital of France?', 
            answers: ['Paris', 'London', 'Berlin', 'Madrid'], 
            correctAnswer: 'Paris' 
        },
        { 
            question: '10.Which planet is known as the Red Planet?', 
            answers: ['Earth', 'Mars', 'Jupiter', 'Venus'], 
            correctAnswer: 'Mars' 
        },
        { 
            question: '11.How many continents are there on Earth?', 
            answers: [5, 6, 7, 8], 
            correctAnswer: 7 
        },
        { 
            question: '12.Who wrote the play "Romeo and Juliet"?', 
            answers: ['William Shakespeare', 'Jane Austen', 'Charles Dickens', 'Leo Tolstoy'], 
            correctAnswer: 'William Shakespeare' 
        },
        { 
            question: '13.What is the largest mammal in the world?', 
            answers: ['Elephant', 'Blue Whale', 'Giraffe', 'Shark'], 
            correctAnswer: 'Blue Whale' 
        },
        { 
            question: '14.What is the boiling point of water at sea level (in °C)?', 
            answers: [90, 95, 100, 105], 
            correctAnswer: 100 
        },
        { 
            question: '15.Which element has the chemical symbol O?', 
            answers: ['Oxygen', 'Osmium', 'Ozone', 'Oganesson'], 
            correctAnswer: 'Oxygen' 
        },
        { 
            question: '16.What is the square root of 144?', 
            answers: [10, 11, 12, 13], 
            correctAnswer: 12 
        },
        { 
            question: '17.How many months are there in a year?', 
            answers: [10, 11, 12, 13], 
            correctAnswer: 12 
        },
        { 
            question: '18.What is the smallest prime number?', 
            answers: [1, 2, 3, 4], 
            correctAnswer: 2 
        },
        { 
            question: '19.What is the freezing point of water (in °C)?', 
            answers: [0, 5, 10, -5], 
            correctAnswer: 0 
        },
        { 
            question: '20.What is the square of 15?', 
            answers: [200, 225, 240, 250], 
            correctAnswer: 225 
        }
    
    
];
let currentQuestionIndex = 0;
let score = 0;

const questionEl = document.getElementById('question');
const answersEl = document.getElementById('answers');
const scoreElement = document.getElementById('score');
const nextQuestionBtn = document.getElementById('next-question');
const skipBtn = document.getElementById('skip-question'); // Skip button

// Load the current question
function loadQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionEl.textContent = currentQuestion.question;

    answersEl.innerHTML = ''; // Clear previous answers
    currentQuestion.answers.forEach(answer => {
        const button = document.createElement('button');
        button.textContent = answer;
        button.onclick = () => checkAnswer(answer, currentQuestion.correctAnswer, button);
        answersEl.appendChild(button);
    });

    nextQuestionBtn.disabled = true; // Disable the next question button until an answer or skip is selected
    skipBtn.disabled = false; // Enable the skip button
}

// Check if the selected answer is correct
function checkAnswer(selectedAnswer, correctAnswer, button) {
    // Disable all buttons once an answer is selected
    const buttons = answersEl.querySelectorAll('button');
    buttons.forEach(btn => btn.disabled = true);

    // Check the answer
    if (selectedAnswer === correctAnswer) {
        score++;
        scoreElement.textContent = score; // Update score display
    }

    nextQuestionBtn.disabled = false; // Enable next question button after an answer or skip
}

// Move to the next question
nextQuestionBtn.onclick = () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        endGame();
    }
};

// Skip the current question
skipBtn.onclick = () => {
    // Disable all buttons and move to the next question
    const buttons = answersEl.querySelectorAll('button');
    buttons.forEach(btn => btn.disabled = true);

    nextQuestionBtn.disabled = false; // Enable next question button

    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        endGame();
    }
};

// End the game and send the score to the server
function endGame() {
    questionEl.textContent = 'Game Over!';
    answersEl.innerHTML = '';
    nextQuestionBtn.style.display = 'none'; // Hide the button
    skipBtn.style.display = 'none'; // Hide the skip button

    sendScoreToServer(score);
}

// Send the score to the server
function sendScoreToServer(score) {
    const username = prompt("Enter your username:");
    if (!username) {
        alert("Username is required!");
        return;
    }

    fetch('/api/scores', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, score })
    })
    .then(response => response.json())
    .then(data => alert('Score saved!'))
    .catch(error => console.error('Error:', error));
}

// Start the game
loadQuestion();
nextQuestionBtn.disabled = true; // Disable the next button initially
skipBtn.disabled = false; // Enable the skip button
