const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/learning_game', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Define score schema
const scoreSchema = new mongoose.Schema({
    username: String,
    score: Number,
});

const Score = mongoose.model('Score', scoreSchema);

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// API endpoint to save scores
app.post('/api/scores', express.json(), async (req, res) => {
    const { username, score } = req.body;
    const newScore = new Score({ username, score });
    await newScore.save();
    res.json({ message: 'Score saved!' });
});
// API endpoint to get all scores (GET)
app.get('/api/scores', async (req, res) => {
    try {
        const scores = await Score.find(); // Fetch all scores from the database
        res.json(scores); // Send the scores as a response in JSON format
    } catch (err) {
        console.error('Error fetching scores:', err);
        res.status(500).json({ message: 'Error fetching scores' });
    }
});

// API endpoint to update a score (PUT method)
app.put('/api/scores/:username', async (req, res) => {
    const { username } = req.params;
    const { score } = req.body;

    if (typeof score !== 'number' || score < 0) {
        return res.status(400).json({ message: 'Invalid score value' });
    }

    try {
        const updatedScore = await Score.findOneAndUpdate(
            { username }, // Find the score by username
            { score },     // Update the score
            { new: true }  // Return the updated document
        );

        if (!updatedScore) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({ message: 'Score updated', score: updatedScore });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating score' });
    }
});

app.delete('/api/scores/:username', async (req, res) => {
    const { username } = req.params;

    try {
        const deletedScore = await Score.findOneAndDelete({ username });

        if (!deletedScore) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({ message: 'Score deleted', score: deletedScore });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting score' });
    }
});

// Start the server
app.listen(4000, () => {
    console.log('Server is running on http://localhost:4000');
});
